export const palette = {
    accent: '#DA1A5F'
}