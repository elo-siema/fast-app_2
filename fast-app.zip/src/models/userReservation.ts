import { MovieShowcase } from "./movieShowcase";

export type UserReservation = {
    userId: string;
    movieShowcase: MovieShowcase;
}