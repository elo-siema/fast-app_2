export type MovieShowcase = {
    id: string;
    date: string;
}