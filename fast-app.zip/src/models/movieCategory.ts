export enum MovieCategory {
    Action = 0,
    Thriller = 1,
    Drama = 2
}