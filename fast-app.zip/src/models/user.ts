export type User = {
    name: string;
    email: string;
    roles?: string[];
    firstName: string;
    token: string;
}