/* eslint-disable @typescript-eslint/ban-types */
import { createContext, FC, PropsWithChildren, useContext, useEffect, useState } from 'react';
import { Movie } from '../models/movie';
import { MovieCategory } from '../models/movieCategory';
import { MovieShowcase } from '../models/movieShowcase';
import { UserReservation } from '../models/userReservation';
import { AuthContext } from './authContext';

export interface MovieContext {
  movies?: Movie[];
  makeReservation: (movieShowcase: MovieShowcase) => Promise<unknown>;
  getReservations: () => Promise<UserReservation[] | undefined>;
}

export const MovieContext = createContext<MovieContext>({
  makeReservation: (movieShowcase: MovieShowcase) => Promise.resolve(),
  getReservations: async () => Promise.resolve(undefined),
});

export const MovieContextProvider: FC<PropsWithChildren<{}>> = ({ children }) => {
  const { user } = useContext(AuthContext);
  const [movies, setMovies] = useState<Movie[]>([]);
  useEffect(() => {
    setTimeout(() => {
      setMovies([
        {
          id: 'ae9f3fff-fbf5-43bf-9748-8c4a2e6fbe82',
          name: 'Deadpool',
          description:
            'amerykański fantastycznonaukowy film akcji na podstawie serii komiksów o antybohaterze o tej samej nazwie wydawnictwa Marvel Comics. Został on wyreżyserowany przez Tima Millera na podstawie scenariusza Rhetta Reese’a i Paula Wernicka',
          movieCategory: MovieCategory.Action,
          imageUrl: 'https://fwcdn.pl/fpo/46/75/514675/7716978.3.jpg',
          shortDescription: 'Amerykański fantastycznonaukowy film',
          showcases: [
            {
              id: 'ccc55909-ba4b-4042-9223-460336356fb5',
              date: '2021-05-31T17:22:41.607Z',
            },
            {
              id: '3312e5df-0fd1-4f1e-bb3e-299a3f68daac',
              date: '2021-05-31T15:22:41.607Z',
            },
          ],
        },
        {
          id: '126a5a6b-9e6d-49d1-81bc-c2d42e641b5e',
          name: 'Titanic',
          description:
            'niemiecki katastroficzny dramat filmowy, nakręcony w 1943, oparty częściowo o autentyczne wydarzenie zatonięcia „Titanica” w 1912. Został wyreżyserowany przez Wernera Klinglera i Herberta Selpina',
          movieCategory: MovieCategory.Drama,
          imageUrl: 'https://fwcdn.pl/fpo/01/87/187/7451731.3.jpg',
          shortDescription: 'Kultowy film',
          showcases: [
            {
              id: 'ccc55909-ba4b-4042-9223-460336356fb5',
              date: '2021-05-31T17:22:41.607Z',
            },
            {
              id: '3312e5df-0fd1-4f1e-bb3e-299a3f68daac',
              date: '2021-05-31T15:22:41.607Z',
            },
          ],
        },
      ]);
    }, 1000);
  }, []);

  const makeReservation = async (movieShowcase: MovieShowcase) => {
    await fetch('https://localhost:44386/api/1.0/reservations', {
      method: 'POST',
      body: JSON.stringify({ movieShowcaseId: movieShowcase.id }),
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${user?.token}`,
      },
    });
  };

  const getReservations = async () => {
    const response = await fetch('https://localhost:44386/api/1.0/reservations', {
      headers: {
        Authorization: `Bearer ${user?.token}`,
      },
    });

    if (response.ok) {
      const reservationsResponse = (await response.json()) as UserReservation[];
      return reservationsResponse;
    }
    return undefined;
  };

  return <MovieContext.Provider value={{ movies, makeReservation, getReservations }}>{children}</MovieContext.Provider>;
};
